package com.example.demo.model;

public class Message {
    String content;
}
