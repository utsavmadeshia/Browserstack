package com.example.demo.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

@Component
@Slf4j
public class LogWatcherService {

    private final String FILE_NAME = "log.txt";
    private final String READ_MODE = "r";
    private final String DESTINATION = "/topic/log";
    private long offset;

    private final RandomAccessFile randomAccessFile;

    @Autowired
    private SimpMessagingTemplate simpMessagingTemplate;

    public LogWatcherService() throws Exception {
        randomAccessFile = new RandomAccessFile(FILE_NAME, READ_MODE);
        offset = getOffset();
    }

    @Scheduled(fixedDelay = 100, initialDelay = 5000)
    public void sendMessage() throws IOException {
        long fileLength = randomAccessFile.length();
        //log.info("offset {}", offset);
        randomAccessFile.seek(offset);

        while (randomAccessFile.getFilePointer() < fileLength) {
            String data = randomAccessFile.readLine();
            String payload = "{\"content\":\"" + data + "\"}";
            log.info("payload {}", payload);

            simpMessagingTemplate.convertAndSend(DESTINATION, payload);
//            try {
//                Thread.sleep(100);
//            } catch (InterruptedException ie) {
//                Thread.currentThread().interrupt();
//            }
            offset=randomAccessFile.getFilePointer();
        }
    }

    private long getOffset() throws IOException {
        int lineCount = 0;
        long currentPosition = 0;
        randomAccessFile.seek(0);
        while(randomAccessFile.readLine()!=null){
            lineCount++;
        }
        randomAccessFile.seek(0);
        log.info("lineCount {}", lineCount);
        if(lineCount <= 10){
            return 0;
        }
        randomAccessFile.seek(0);
        int targetLine = lineCount-10;
        int curline = 0;
        while(curline < targetLine){
            randomAccessFile.readLine();
            curline++;
        }
        currentPosition = randomAccessFile.getFilePointer();
        return currentPosition;
    }
}
